﻿function loadPlayer(id, options) {
    videojs(id, options);
}